//
//  MMBookmarksViewController.h
//  MobMonkey
//
//  Created by Dan Brajkovic on 10/11/12.
//  Copyright (c) 2012 Reyaad Sidique. All rights reserved.
//

#import "MMLocationsViewController.h"

@interface MMBookmarksViewController : MMLocationsViewController

@end
