//
//  MMConstants.h
//  MobMonkey
//
//  Created by Dan Brajkovic on 10/16/12.
//  Copyright (c) 2012 Reyaad Sidique. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef enum UIActionSheetCalls {
    twitterAccountsActionSheetCall,
    genderActionSheetCall,
}UIActionSheetCalls;

@interface MMConstants : NSObject

@end
