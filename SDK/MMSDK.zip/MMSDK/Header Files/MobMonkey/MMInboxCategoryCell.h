//
//  MMInboxCategoryCell.h
//  MobMonkey
//
//  Created by Reyaad Sidique on 10/7/12.
//  Copyright (c) 2012 Reyaad Sidique. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MMInboxCategoryCell : MMTableViewCell

@property (nonatomic, retain) UILabel *categoryItemCountLabel;
@property (nonatomic, retain) UIImageView *pillboxImageView;

@end
