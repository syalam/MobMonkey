//
//  MMTextFieldCell.h
//  MobMonkey
//
//  Created by Reyaad Sidique on 1/3/13.
//  Copyright (c) 2013 Reyaad Sidique. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MMTextFieldCell : UITableViewCell

@property (nonatomic, retain) UITextField *textField;

@end
