//
//  MMSetTitleImage.h
//  MobMonkey
//
//  Created by Reyaad Sidique on 9/2/12.
//  Copyright (c) 2012 Reyaad Sidique. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MMSetTitleImage : NSObject

-(UIImageView*)setTitleImageView;


@property (nonatomic, retain)UIImage *mmTitleImage;

@end
