//
//  MMTabBarViewController.h
//  MobMonkey
//
//  Created by Reyaad Sidique on 10/8/12.
//  Copyright (c) 2012 Reyaad Sidique. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MMTabBarViewController : UITabBarController

@end
