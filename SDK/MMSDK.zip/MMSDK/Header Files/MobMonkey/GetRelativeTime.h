//
//  GetRelativeTime.h
//  MobMonkey
//
//  Created by Reyaad Sidique on 8/14/12.
//
//

#import <Foundation/Foundation.h>

@interface GetRelativeTime : NSObject

+ (NSString*)getRelativeTime:(NSDate*)date;

@end
