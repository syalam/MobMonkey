//
//  MMStyleTheme.h
//  MobMonkey
//
//  Created by Michael Kral on 4/5/13.
//  Copyright (c) 2013 Reyaad Sidique. All rights reserved.
//

#import <Foundation/Foundation.h>

/** This object contains the UIColors, UIImages, etc for the style of the ViewController to be presented. */
@interface MMStyleTheme : NSObject

/** The background image for the back bar button item. */
@property (nonatomic, strong) UIImage * buttonBackgoundImage;

/** The background color of the to be presented view controller. */
@property (nonatomic, strong) UIColor * backgroundColor;

/** The image to appear along side the title in the navigation bar. */
@property (nonatomic, strong) UIImage * navigationBarTitleImage;

/** The tint color (UIAppearance) of the navigation bar. */
@property (nonatomic, strong) UIColor * navigationBarTintColor;


/** Creates an instance of MMStyleTheme to be used with the MMSDK for styling view controllers
 
 @param buttonBackgroundImage The background image for the back bar button item.
 @param backgroundColor The color of the back bar button item.
 @param navigationBarTitleImage The image to appear along side the title in the navigation bar.
 @param navigationBarTintColor The tint color (UIAppearance) of the navigation bar.
 */
+(MMStyleTheme*)styleWithButtonBackgroundImage:(UIImage*)buttonBackgroundImage backgroundColor:(UIColor*)backgroundColor navigationBarTitleImage:(UIImage*)navigationBarTitleImage navigationBarTintColor:(UIColor *) navigationBarTintColor;

@end
