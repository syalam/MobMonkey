//
//  MMStyleTheme.m
//  MobMonkey
//
//  Created by Michael Kral on 4/5/13.
//  Copyright (c) 2013 Reyaad Sidique. All rights reserved.
//

#import "MMStyleTheme.h"

@implementation MMStyleTheme

@synthesize navigationBarTintColor, navigationBarTitleImage, buttonBackgoundImage, backgroundColor;

+(MMStyleTheme*)styleWithButtonBackgroundImage:(UIImage*)buttonBackgroundImage backgroundColor:(UIColor*)backgroundColor navigationBarTitleImage:(UIImage*)navigationBarTitleImage navigationBarTintColor:(UIColor *) navigationBarTintColor {
    
    MMStyleTheme *styleTheme = [[self alloc] init];
    
    styleTheme.backgroundColor = backgroundColor;
    styleTheme.buttonBackgoundImage = buttonBackgroundImage;
    styleTheme.navigationBarTitleImage = navigationBarTitleImage;
    styleTheme.navigationBarTintColor = navigationBarTintColor;
    
    return styleTheme;
}

@end
