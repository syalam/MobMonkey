//
//  MMSDK.m
//  MMSDK
//
//  Created by Reyaad Sidique on 2/13/13.
//  Copyright (c) 2013 Reyaad Sidique. All rights reserved.
//

#import "MMSDK.h"
#import "MMLoginViewController.h"
#import "MMSignUpViewController.h"
#import "MMInboxViewController.h"
#import "MMInboxDetailViewController.h"
#import "MMAnsweredRequestsViewController.h"
#import "MMLocationViewController.h"
#import "MMRequestViewController.h"
#import "MMSearchViewController.h"
#import "MMSubscriptionViewController.h"


@interface MMSDK ()

- (void)MMActivateLocationServices;

@end

@implementation MMSDK

#pragma mark - Class Methods

+ (MMSDK*)sharedSDK {
    static dispatch_once_t once;
    static MMSDK *sharedSDK;
    dispatch_once(&once, ^ { sharedSDK = [[MMSDK alloc] init]; });
    return sharedSDK;
}

+ (void)MMActivateLocationServices {
    
    //Assert that the facebook id's are set
    NSString *facebookID = [[NSBundle mainBundle] objectForInfoDictionaryKey:@"FacebookAppID"];
    
    NSAssert(facebookID, @"You need to add your facebook app ID to the Info.plist see: https://developers.facebook.com/docs/getting-started/facebook-sdk-for-ios/");
    
    [[MMSDK sharedSDK]MMActivateLocationServices];
}

+ (void)displayMMSignInScreenFromPresentingViewController:(UIViewController*)presentingViewController withStyleTheme:(MMStyleTheme *)styleTheme{
    
    NSDictionary *styleThemeDictionary = @{
                                           
                                           @"backgroundColor":styleTheme.backgroundColor,
                                           @"buttonBackgroundImage":styleTheme.buttonBackgoundImage,
                                           @"navigationBarTintColor":styleTheme.navigationBarTintColor,
                                           @"navigationBarTitleImage":styleTheme.navigationBarTitleImage
                                           
                                           };
    
    MMLoginViewController *signInVc = [[MMLoginViewController alloc]initWithNibName:@"MMLoginViewController" bundle:nil];
    signInVc.title = @"Sign In";
    signInVc.themeOptionsDictionary = styleThemeDictionary;
    UINavigationController *navC = [[UINavigationController alloc]initWithRootViewController:signInVc];
    [presentingViewController.navigationController presentViewController:navC animated:YES completion:NULL];
}

+ (void)displayMMSignUpScreenFromPresentingViewController:(UIViewController*)presentingViewController withStyleTheme:(MMStyleTheme *)styleTheme{
    
    NSDictionary *styleThemeDictionary = @{
                                           
                                           @"backgroundColor":styleTheme.backgroundColor,
                                           @"buttonBackgroundImage":styleTheme.buttonBackgoundImage,
                                           @"navigationBarTintColor":styleTheme.navigationBarTintColor,
                                           @"navigationBarTitleImage":styleTheme.navigationBarTitleImage
                                           
                                           };
    
    MMSignUpViewController *signUpVC = [[MMSignUpViewController alloc]initWithNibName:@"MMSignUpViewController" bundle:nil];
    signUpVC.themeOptionsDictionary = styleThemeDictionary;
    signUpVC.title = @"Sign Up";
    [presentingViewController.navigationController pushViewController:signUpVC animated:YES];
}

+ (void)displayMMInboxScreenFromPresentingViewController:(UIViewController*)presentingViewController withStyleTheme:(MMStyleTheme *)styleTheme{
    
    NSDictionary *styleThemeDictionary = @{
                                           
                                           @"backgroundColor":styleTheme.backgroundColor,
                                           @"buttonBackgroundImage":styleTheme.buttonBackgoundImage,
                                           @"navigationBarTintColor":styleTheme.navigationBarTintColor,
                                           @"navigationBarTitleImage":styleTheme.navigationBarTitleImage
                                           
                                           };
    
    MMInboxViewController *inboxVC = [[MMInboxViewController alloc]initWithNibName:@"MMInboxViewController" bundle:nil];
    inboxVC.title = @"Inbox";
    inboxVC.themeOptionsDictionary = styleThemeDictionary;
    [presentingViewController.navigationController pushViewController:inboxVC animated:YES];
}

+ (void)displayMMOpenRequestsScreenFromPresentingViewController:(UIViewController*)presentingViewController withStyleTheme:(MMStyleTheme *)styleTheme{
    
    NSDictionary *styleThemeDictionary = @{
                                           
                                           @"backgroundColor":styleTheme.backgroundColor,
                                           @"buttonBackgroundImage":styleTheme.buttonBackgoundImage,
                                           @"navigationBarTintColor":styleTheme.navigationBarTintColor,
                                           @"navigationBarTitleImage":styleTheme.navigationBarTitleImage
                                           
                                           };
    
    MMInboxDetailViewController *inboxDetailVC = [[MMInboxDetailViewController alloc]initWithNibName:@"MMInboxDetailViewController" bundle:nil];
    inboxDetailVC.title = @"Open Requests";
    inboxDetailVC.themeOptionsDictionary = styleThemeDictionary;
    [presentingViewController.navigationController pushViewController:inboxDetailVC animated:YES];
}

+ (void)displayMMAnsweredRequestsScreenFromPresentingViewController:(UIViewController*)presentingViewController withStyleTheme:(MMStyleTheme *)styleTheme{
    
    NSDictionary *styleThemeDictionary = @{
                                           
                                           @"backgroundColor":styleTheme.backgroundColor,
                                           @"buttonBackgroundImage":styleTheme.buttonBackgoundImage,
                                           @"navigationBarTintColor":styleTheme.navigationBarTintColor,
                                           @"navigationBarTitleImage":styleTheme.navigationBarTitleImage
                                           
                                           };
    
    MMAnsweredRequestsViewController *answeredRequestsVC = [[MMAnsweredRequestsViewController alloc]initWithNibName:@"MMAnsweredRequestsViewController" bundle:nil];
    answeredRequestsVC.title = @"AnsweredRequests";
    answeredRequestsVC.themeOptionsDictionary = styleThemeDictionary;
    [presentingViewController.navigationController pushViewController:answeredRequestsVC animated:YES];
}

+ (void)displayMMAssignedRequestsScreenFromPresentingViewController:(UIViewController*)presentingViewController withStyleTheme:(MMStyleTheme *)styleTheme{
    
    NSDictionary *styleThemeDictionary = @{
                                           
                                           @"backgroundColor":styleTheme.backgroundColor,
                                           @"buttonBackgroundImage":styleTheme.buttonBackgoundImage,
                                           @"navigationBarTintColor":styleTheme.navigationBarTintColor,
                                           @"navigationBarTitleImage":styleTheme.navigationBarTitleImage
                                           
                                           };
    MMInboxDetailViewController *inboxDetailVC = [[MMInboxDetailViewController alloc]initWithNibName:@"MMInboxDetailViewController" bundle:nil];
    inboxDetailVC.title = @"Assigned Requests";
    inboxDetailVC.themeOptionsDictionary = styleThemeDictionary;
    [presentingViewController.navigationController pushViewController:inboxDetailVC animated:YES];
}

+ (void)displayMMLocationDetailScreenFromPresentingViewController:(UIViewController*)presentingViewController withLocation:(MMLocation*)location withStyleTheme:(MMStyleTheme *)styleTheme{
    
    NSDictionary *styleThemeDictionary = @{
                                           
                                           @"backgroundColor":styleTheme.backgroundColor,
                                           @"buttonBackgroundImage":styleTheme.buttonBackgoundImage,
                                           @"navigationBarTintColor":styleTheme.navigationBarTintColor,
                                           @"navigationBarTitleImage":styleTheme.navigationBarTitleImage
                                           
                                           };
    NSDictionary *locationDictionary = @{
                                         
                                         @"locationId":location.locationID,
                                         @"providerId":location.providerID
                                         
                                         };
    
    MMLocationViewController *locationVC = [[MMLocationViewController alloc]initWithNibName:@"MMLocationViewController" bundle:nil];
    locationVC.themeOptionsDictionary = styleThemeDictionary;
    [locationVC loadLocationDataWithLocationId:location.locationID providerId:location.providerID];
    [presentingViewController.navigationController pushViewController:locationVC animated:YES];
}

+ (void)displayMMMakeARequestScreenFromPresentingViewController:(UIViewController*)presentingViewController withLocation:(MMLocation*)location withStyleTheme:(MMStyleTheme *)styleTheme {
    
    NSDictionary *styleThemeDictionary = @{
                                           
                                           @"backgroundColor":styleTheme.backgroundColor,
                                           @"buttonBackgroundImage":styleTheme.buttonBackgoundImage,
                                           @"navigationBarTintColor":styleTheme.navigationBarTintColor,
                                           @"navigationBarTitleImage":styleTheme.navigationBarTitleImage
                                           
                                           };

    
    NSDictionary *locationDictionary = @{
                                         
                                         @"locationId":location.locationID,
                                         @"providerId":location.providerID
                                         
                                         };

    MMRequestViewController *requestVC = [[MMRequestViewController alloc]initWithNibName:@"MMRequestViewController" bundle:nil];
    requestVC.themeOptionsDictionary = styleThemeDictionary;
    [requestVC setContentList:locationDictionary];
    UINavigationController *requestNavC = [[UINavigationController alloc]initWithRootViewController:requestVC];
    [presentingViewController.navigationController presentViewController:requestNavC animated:YES completion:NULL];
}

+ (void)displayMMSearchScreenFromPresentingViewController:(UIViewController*)presentingViewController withStyleTheme:(MMStyleTheme *)styleTheme{
    
    NSDictionary *styleThemeDictionary = @{
                                           
                                           @"backgroundColor":styleTheme.backgroundColor,
                                           @"buttonBackgroundImage":styleTheme.buttonBackgoundImage,
                                           @"navigationBarTintColor":styleTheme.navigationBarTintColor,
                                           @"navigationBarTitleImage":styleTheme.navigationBarTitleImage
                                           
                                           };
    
    MMSearchViewController *searchVC = [[MMSearchViewController alloc]initWithNibName:@"MMSearchViewController" bundle:nil];
    searchVC.title = @"Search";
    searchVC.themOptionsDictionary = styleThemeDictionary;
    searchVC.pushedView = YES;
    [presentingViewController.navigationController pushViewController:searchVC animated:YES];
}

+ (void)displayMMSubscriptionViewController:(UIViewController*)presentingViewController withStyleTheme:(MMStyleTheme *)styleTheme{
    
    NSDictionary *styleThemeDictionary = @{
                                           
                                           @"backgroundColor":styleTheme.backgroundColor,
                                           @"buttonBackgroundImage":styleTheme.buttonBackgoundImage,
                                           @"navigationBarTintColor":styleTheme.navigationBarTintColor,
                                           @"navigationBarTitleImage":styleTheme.navigationBarTitleImage
                                           
                                           };
    

    MMSubscriptionViewController *subscriptionVC = [[MMSubscriptionViewController alloc]initWithNibName:@"MMSubscriptionViewController" bundle:nil];
    [presentingViewController.navigationController pushViewController:subscriptionVC animated:YES];
}

#pragma mark - Instance methods
- (void)MMActivateLocationServices {
    _locationManager = [[CLLocationManager alloc]init];
    _locationManager.delegate = self;
    _locationManager.desiredAccuracy =kCLLocationAccuracyBest;
    _locationManager.distanceFilter = 60.0f; // update every 200ft
    [_locationManager startUpdatingLocation];
}

#pragma mark - CLLocationServices Delegate Methods
- (void)locationManager:(CLLocationManager *)manager
     didUpdateLocations:(NSArray *)locations {
    // If it's a relatively recent event, turn off updates to save power
    CLLocation* newLocation = [locations lastObject];
    [[NSUserDefaults standardUserDefaults]setObject:[NSString stringWithFormat:@"%f", newLocation.coordinate.latitude] forKey:@"latitude"];
    [[NSUserDefaults standardUserDefaults]setObject:[NSString stringWithFormat:@"%f", newLocation.coordinate.longitude] forKey:@"longitude"];
    [[NSUserDefaults standardUserDefaults]synchronize];
    NSMutableDictionary *params = [[NSMutableDictionary alloc]init];
    [params setObject:[NSNumber numberWithDouble:newLocation.coordinate.latitude] forKey:@"latitude"];
    [params setObject:[NSNumber numberWithDouble:newLocation.coordinate.longitude] forKey:@"longitude"];
    
    NSLog(@"%@, %@", [[NSUserDefaults standardUserDefaults]objectForKey:@"latitude"], [[NSUserDefaults standardUserDefaults]objectForKey:@"longitude"]);
    
    [MMAPI checkUserIn:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSLog(@"%@", @"Checked in");
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"%@", @"Unable to check in");
    }];
}

- (void)locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error {
    NSLog(@"%@", error);
}

@end
