//
//  MMLocation.h
//  MobMonkey
//
//  Created by Michael Kral on 4/5/13.
//  Copyright (c) 2013 Reyaad Sidique. All rights reserved.
//

#import <Foundation/Foundation.h>

/** This object contains the LocationID and ProviderID needed to get information from a location */
@interface MMLocation : NSObject

/** NSString of the Location ID. */
@property (nonatomic, strong) NSString * locationID;

/** NSString of the Provider ID. */
@property (nonatomic, strong) NSString * providerID;


/** Creates an instance of a MMLocation object with location ID and provider ID
 
 @param locationID The ID for the Location in database.
 @param providerID The ID for the Provider in database.
 */
+(MMLocation*)locationID:(NSString *)locationID providerID:(NSString *)providerID;

@end
