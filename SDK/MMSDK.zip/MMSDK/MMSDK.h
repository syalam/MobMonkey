//
//  MMSDK.h
//  MMSDK
//
//  Created by Reyaad Sidique on 2/13/13.
//  Copyright (c) 2013 Reyaad Sidique. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreLocation/CoreLocation.h>

#import "MMStyleTheme.h"
#import "MMLocation.h"

/** This SDK is intended to be used within 3rd party apps to leverage the capabilities of MobMonkey and integrate the workflow within your app.*/
@interface MMSDK : NSObject <CLLocationManagerDelegate>

@property (nonatomic, retain)CLLocationManager *locationManager;

///---------------------------------------------
/// @name MMActivateLocationServices
///---------------------------------------------
/**
 Activates location services. Should be called from appDidLaunch method in app delegate
 */
+(void)MMActivateLocationServices;


///---------------------------------------------
/// @name displayMMSignInScreenFromPresentingViewController
///---------------------------------------------
/**
 Displays the MobMonkey Sign in Screen from a specified view controller
 
 @param presentingViewController The UIViewController that will present the Sign In screen.
 @param styleTheme The MMStyleTheme for the View Controller to be presented.

 */
+ (void)displayMMSignInScreenFromPresentingViewController:(UIViewController*)presentingViewController withStyleTheme:(MMStyleTheme *)styleTheme;


///---------------------------------------------
/// @name displayMMSignUpScreenFromPresentingViewController
///---------------------------------------------
/**
 Displays the MobMonkey Sign Up Screen from a specified view controller
 
 @param presentingViewController The UIViewController that will present the Sign Up screen.
 @param styleTheme The MMStyleTheme for the View Controller to be presented.
 */
+ (void)displayMMSignUpScreenFromPresentingViewController:(UIViewController*)presentingViewController withStyleTheme:(MMStyleTheme *)styleTheme;


///---------------------------------------------
/// @name displayMMInboxScreenFromPresentingViewController
///---------------------------------------------
/**
 Displays the MobMonkey inbox Screen from a specified view controller
 
 @param presentingViewController The UIViewController that will present the Inbox Screen screen.
 @param styleTheme The MMStyleTheme for the View Controller to be presented.
 
 */
+ (void)displayMMInboxScreenFromPresentingViewController:(UIViewController*)presentingViewController withStyleTheme:(MMStyleTheme *)styleTheme;

///---------------------------------------------
/// @name displayMMOpenRequestsScreenFromPresentingViewController
///---------------------------------------------
/**
 Displays the MobMonkey Open Requests Screen from a specified view controller
 
 @param presentingViewController The UIViewController that will present the Open Requests screen.
 @param styleTheme The MMStyleTheme for the View Controller to be presented.
 
 */
+ (void)displayMMOpenRequestsScreenFromPresentingViewController:(UIViewController*)presentingViewController withStyleTheme:(MMStyleTheme *)styleTheme;

///---------------------------------------------
/// @name displayMMAnsweredRequestsScreenFromPresentingViewController
///---------------------------------------------
/**
 Displays the MobMonkey Answered Requests Screen from a specified view controller
 
 @param presentingViewController The UIViewController that will present the Answered Requests screen.
 @param styleTheme The MMStyleTheme for the View Controller to be presented.
 */
+ (void)displayMMAnsweredRequestsScreenFromPresentingViewController:(UIViewController*)presentingViewController withStyleTheme:(MMStyleTheme *)styleTheme;

///---------------------------------------------
/// @name displayMMAssignedRequestsScreenFromPresentingViewController
///---------------------------------------------
/**
 Displays the MobMonkey Answered Requests Screen from a specified view controller
 
 @param presentingViewController The UIViewController that will present the Assigned Requests screen.
 @param styleTheme The MMStyleTheme for the View Controller to be presented.
 */

+ (void)displayMMAssignedRequestsScreenFromPresentingViewController:(UIViewController*)presentingViewController withStyleTheme:(MMStyleTheme *)styleTheme;


///---------------------------------------------
/// @name displayMMLocationDetailScreenFromPresentingViewController:withLocationParams
///---------------------------------------------
/**
 Displays the MobMonkey Answered Requests Screen from a specified view controller.
 
 @param presentingViewController The UIViewController that will present the Location Detail screen.
 @param styleTheme The MMStyleTheme for the View Controller to be presented.
 @param location The MMLocation of the Location being shown in view controller to be presented.
 */
+ (void)displayMMLocationDetailScreenFromPresentingViewController:(UIViewController*)presentingViewController withLocation:(MMLocation*)location withStyleTheme:(MMStyleTheme *)styleTheme;


///---------------------------------------------
/// @name displayMMMakeARequestScreenFromPresentingViewController:withLocationParams
///---------------------------------------------
/**
 Displays the MobMonkey Answered Requests Screen from a specified view controller.
 
 @param presentingViewController The UIViewController that will present the Make a request screen.
 @param styleTheme The MMStyleTheme for the View Controller to be presented.
 @param location The MMLocation of the Location being shown in view controller to be presented.
 */
+ (void)displayMMMakeARequestScreenFromPresentingViewController:(UIViewController*)presentingViewController withLocation:(MMLocation*)location withStyleTheme:(MMStyleTheme *)styleTheme;

///---------------------------------------------
/// @name displayMMSearchScreenFromPresentingViewController:presentingViewControllerwithStyleTheme:
///---------------------------------------------
/**
 Displays the MobMonkey Search Screen from a specified view controller
 
 @param presentingViewController The UIViewController that will present the Search Screen screen.
 @param styleTheme The MMStyleTheme for the View Controller to be presented.
 */
+ (void)displayMMSearchScreenFromPresentingViewController:(UIViewController*)presentingViewController withStyleTheme:(MMStyleTheme *)styleTheme;


///---------------------------------------------
/// @name displayMMSubscriptionViewController:presentingViewControllerwithStyleTheme:
///---------------------------------------------
/**
 Displays the MobMonkey Subscription Screen from a specified view controller
 
 @param presentingViewController The UIViewController that will present the Subscription screen.
 @param styleTheme The MMStyleTheme for the View Controller to be presented.
 */
+ (void)displayMMSubscriptionViewController:(UIViewController*)presentingViewController withStyleTheme:(MMStyleTheme *)styleTheme;


@end
