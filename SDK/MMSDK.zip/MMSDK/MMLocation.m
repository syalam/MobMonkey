//
//  MMLocation.m
//  MobMonkey
//
//  Created by Michael Kral on 4/5/13.
//  Copyright (c) 2013 Reyaad Sidique. All rights reserved.
//

#import "MMLocation.h"

@implementation MMLocation

@synthesize providerID, locationID;

+(MMLocation *)locationID:(NSString *)locationID providerID:(NSString *)providerID{
    
    MMLocation *location = [[self alloc] init];
    
    location.locationID = locationID;
    location.providerID = providerID;
    
    return location;
}

@end
